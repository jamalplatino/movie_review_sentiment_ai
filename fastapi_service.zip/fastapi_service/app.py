from pathlib import Path
import joblib
from fastapi import FastAPI
from pydantic import BaseModel

# ------------------------------------------------------------------
# 1. Load the model and vectorizer once when the module is imported
# ------------------------------------------------------------------
MODEL_DIR = Path(__file__).resolve().parent / "sentiment_model"

model = joblib.load(MODEL_DIR / "model.pkl")
vectorizer = joblib.load(MODEL_DIR / "vectorizer.pkl")


# ------------------------------------------------------------------
# 2. Pydantic models for request and response
# ------------------------------------------------------------------
class PredictRequest(BaseModel):
    text: str

class PredictResponse(BaseModel):
    sentiment: str
    confidence: float

# ------------------------------------------------------------------
# 3. FastAPI app instance
# ------------------------------------------------------------------
app = FastAPI(
    title="Sentiment Analysis Microservice",
    version="0.1.0",
)

# ------------------------------------------------------------------
# 4. Prediction endpoint
# ------------------------------------------------------------------
@app.post("/predict", response_model=PredictResponse)
def predict(request: PredictRequest):
    # Transform the input text using the loaded vectorizer
    X = vectorizer.transform([request.text])

    # Get the predicted class (0=negative, 1=positive)
    prediction = model.predict(X)[0]
    # Get the highest class probability as confidence
    confidence = model.predict_proba(X)[0].max()

    sentiment = "positive" if prediction == 1 else "negative"

    return PredictResponse(sentiment=sentiment, confidence=round(float(confidence), 4))


# ------------------------------------------------------------------
# 5. Health check (good for Docker/Kubernetes later)
# ------------------------------------------------------------------
@app.get("/health")
def health():
    return {"status": "ok"}
